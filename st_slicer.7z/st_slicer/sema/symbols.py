from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional

from ..ast.nodes import Expr


@dataclass
class VarSymbol:
    name: str
    type: str
    storage: str
    init_expr: Optional[Expr]


@dataclass
class FBSymbol:
    name: str
    type: str  # FB 类型名


@dataclass
class POUSymbolTable:
    name: str
    vars: Dict[str, VarSymbol]
    fb_instances: Dict[str, FBSymbol]

    def add_var(self, sym: VarSymbol):
        self.vars[sym.name] = sym

    def add_fb_instance(self, sym: FBSymbol):
        self.fb_instances[sym.name] = sym


class ProjectSymbolTable:
    def __init__(self):
        self.pous: Dict[str, POUSymbolTable] = {}
        self.globals: Dict[str, VarSymbol] = {}

    def add_pou(self, pou: POUSymbolTable):
        self.pous[pou.name] = pou
